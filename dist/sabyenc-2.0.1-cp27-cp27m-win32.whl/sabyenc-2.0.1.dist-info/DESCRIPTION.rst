yEnc Encoding/Decoding for Python
---------------------------------

Mofied the original yenc module by Alessandro Duca <alessandro.duca@gmail.com>
for use within SABnzbd.

This a fairly simple module, it provide only raw yEnc encoding/decoding with
builitin crc32 calculation. Header parsing, checkings and yenc formatting are 
left to you (see examples directory for possible implementations). 

Supports encoding and decoding directly to files or to memory buffers
with helper classes Encoder and Decoder.


